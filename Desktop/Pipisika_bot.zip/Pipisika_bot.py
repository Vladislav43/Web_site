
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor

import random

from time import time as now

import markup as nav

import sqlite3

import re

import Token as token

db = sqlite3.connect('server_pisiun.db')
sql = db.cursor()

sql.execute("""CREATE TABLE IF NOT EXISTS piski_users (
	user TEXT,
	count_piska INT,
	user_name TEXT,
	chat_id TEXT,
	user_time INT
)""")

db.commit()

from Token import TOKEN

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def start_command(message: types.Message):
	try:
		await bot.send_message(message.from_user.id, "Слава Україні, козаче! Я виміряю твій пісюн сьогодні!\n\nДобав мене в групу і починайте мірятися пісюнами!!!\n\nТакож у нас є телеграм канал: https://t.me/Huge_piska_channel")
	except:
		await message.answer("Напиши мені в лічку брат!")

@dp.message_handler(commands=['help'])
async def help_command(message: types.Message):
	if 1 == 1:
		print("hello")
	await message.reply("Козаче, добав мене в групу і пиши команду '/pisun_grow_up'\n\nІ побачимо який в тебе пеніс!\n\nТакож наші команди це: /start, /help, /pisun_grow_up, /my_pisun, /top_pisun_chat, /top_pisun_global, /contacts, /help_ukraine, /pisun_flip_coin(/pisun_flip_coin Орел(Решка) 10(Ставка))\n\nТакож підписуйся на телеграм канал: https://t.me/Huge_piska_channel")

last_use = {"penis": 0}
cooldown = 14400

'''MAIN CODE'''
@dp.message_handler(commands=['pisun_grow_up'])
async def grow_up_command(message: types.Message):
		pisika_grow_num = random.randint(-5, 10)
		users = message.from_user.id
		first_name_user = message.from_user.first_name
		chat_id = message.chat.id
		sql.execute(f'SELECT user FROM piski_users WHERE user = "{users}" AND chat_id = "{chat_id}"')
		if sql.fetchone() is None:
			sql.execute(f"INSERT INTO piski_users VALUES (?, ?, ?, ?, ?)", (users, pisika_grow_num, first_name_user, chat_id, last_use["penis"]))
			db.commit()
			await message.reply(f"Вітаємо, {first_name_user} з новим пенісом!\nКозаче, твій пеніс зараз *{pisika_grow_num}см.*\n\nТи можеш використати ще одну спробу!)", parse_mode="Markdown")
		else:
			for t in sql.execute(f"SELECT user_time FROM piski_users WHERE user = '{users}' AND chat_id = '{chat_id}'"):
				t = int(t[0])
				if now() > t + cooldown:
					t = now()
					sql.execute(f"UPDATE piski_users SET user_time = '{t}' WHERE user = '{users}' AND chat_id = '{chat_id}'")
					db.commit()
					for i in sql.execute(F"SELECT count_piska FROM piski_users WHERE user = '{users}' AND chat_id = '{chat_id}'"):
						balans_piska = i[0]
					count_piska = pisika_grow_num + balans_piska
					sql.execute(f"UPDATE piski_users SET count_piska = {count_piska} WHERE user = '{users}' AND chat_id = '{chat_id}'")
					db.commit()
					if pisika_grow_num > 0:
						await message.reply(f"{first_name_user} вітаємо! Козаче, твій пеніс зараз *{count_piska}см.* Він збільшився на *{pisika_grow_num}см.*", parse_mode="Markdown")
					elif pisika_grow_num < 0:
						await message.reply(f"Козаче, не твій день! Твій пеніс зменшився на *{pisika_grow_num}см.*\n\nТепер він *{count_piska}см.* Брат сьогодні може холодно, такшо не засмучуйся!", parse_mode="Markdown")
					else:
						await message.reply(f"Козаче, твій пеніс залишається *{count_piska}*", parse_mode="Markdown")
				else:
					await message.reply("Козаче, твій пеніс не може рости так швидко!!!\nДай йому час! Йди пиздити москалів, через 4 години вертайся і виращуй пісюн!!!\n\nТакож у нас є телеграм канал: https://t.me/Huge_piska_channel")

@dp.message_handler(commands=['my_pisun'])
async def my_pisiun_command(message: types.Message):
	users = message.from_user.id
	chat_id = message.chat.id
	for value in sql.execute(f"SELECT count_piska FROM piski_users WHERE user = '{users}' AND chat_id = '{chat_id}'"):
		await message.reply(f"Козаче, вітаємо! Твій пеніс зараз *{value[0]}см.*\n\nМаєш гарний член - брате! Йди хуяр москалів ним!", parse_mode="Markdown")

@dp.message_handler(commands=['top_pisun_chat'])
async def top_pisiun(message: types.Message):
	users = message.from_user.id
	chat_id = message.chat.id
	await message.reply(f"Учасники групи мають такі пеніси:")
	num_top = str(1)
	for p, c in sql.execute(f"SELECT user_name, count_piska FROM piski_users WHERE chat_id = '{chat_id}' ORDER BY count_piska DESC"):
		await message.answer(f"{num_top}. *{p}* - *{c}см.*", parse_mode="Markdown")
		num_top = int(num_top) + 1
		num_top = str(num_top)


@dp.message_handler(commands=['top_pisun_global'])
async def top_pisiun(message: types.Message):
	if message.chat.type == 'private':
		users = message.from_user.id
		chat_id = message.chat.id
		await message.reply(f"Учасники мають такі пеніси:")
		num_top = str(1)
		arr = []
		for p, c in sql.execute(f"SELECT user_name, count_piska FROM piski_users ORDER BY count_piska DESC"):
			bool_arr = bool(p in arr)
			if bool_arr:
				continue
			else:
				await message.answer(f"{num_top}. *{p}* - *{c}см.*", parse_mode="Markdown")
				num_top = int(num_top) + 1
				if num_top == 11:
					break
				num_top = str(num_top)
				arr.append(p)
				print(arr)
		await message.reply("Також у нас є телеграм канал: https://t.me/Huge_piska_channel")
	else:
		await message.reply("Чекнути топ можеш тільки в лічці!)")


@dp.message_handler(commands=['pisun_flip_coin'])
async def coin_flip(message: types.Message):
	try:
		users = message.from_user.id
		chat_id = message.chat.id
		text = message.text[17:22]
		for i in sql.execute(F"SELECT count_piska FROM piski_users WHERE user = '{users}' AND chat_id = '{chat_id}'"):
			balans_piska = i[0]
		deposit = message.text[22:]
		deposit = int(deposit)
		text = str(text.lower())
		if balans_piska < deposit or deposit > 10 or deposit == 0:
			await message.reply(f"Не можна поставити більше см чим ти маєш і максимальна ставка це 10см!!")
		else:
			if text.lower() == "решка" or text.lower() == "орел ":		
				rand_num = random.randint(1, 2)
				if rand_num == 1:
					count_piska = deposit + balans_piska
					sql.execute(f"UPDATE piski_users SET count_piska = {count_piska} WHERE user = '{users}' AND chat_id = '{chat_id}'")
					db.commit()
					await message.reply(f"Ти виграв!! Твій пеніс зараз {count_piska}")
				else:
					if balans_piska > deposit and balans_piska < 0:	
						count_piska = deposit - balans_piska
					else:
						count_piska = balans_piska - deposit
					sql.execute(f"UPDATE piski_users SET count_piska = {count_piska} WHERE user = '{users}' AND chat_id = '{chat_id}'")
					db.commit()
					await message.reply(f"Ти програв(! Твій пеніс зараз {count_piska}")
	except:
		await message.reply(f"Ти написав щось не равельно! Перевір: /pisun_flip_coin (Орел/Решка) (І цифра сантиметрів без СМ!)")



'''ADMIN'''
@dp.message_handler(commands=['adm_check_data_base'])
async def adm_data_base_checker(message: types.Message):
	if message.from_user.id == 556800472 or message.from_user.id == 1135990468:
		if message.chat.type == 'private':
			for p in sql.execute(f"SELECT * FROM piski_users"):
				await message.reply(p)
				print(p)
		else:
			await message.reply(f"Володимире(Денисе)! Напишыть це мені в лічку!!!")
	else:
		await message.reply(f"Воу-воу, ти бля не спіши! Це адмін команда!)")


def get_user():
	return sql.execute("SELECT chat_id FROM piski_users").fetchall()


@dp.message_handler(commands=['send_message_all_users'])
async def send_message_all_users(message:types.Message):
	if message.chat.type == 'private':
		if message.from_user.id == 556800472 or message.from_user.id == 1135990468:
			text = message.text[24:]
			users = get_user()
			arr = []
			for row in users:
				bool_arr = bool(row in arr)
				if bool_arr:
					continue
				else:
					try:
						await bot.send_message(row[0], text)
						arr.append(row)
					except:
						continue
		else:
			await message.reply(f"Володимире(Денисе)! Напишыть це мені в лічку!!!")
	else:
		await message.reply(f"Воу-воу, ти бля не спіши! Це адмін команда!)")


'''EXTRA CODE'''
@dp.message_handler(commands=['contacts'])
async def contact(message: types.Message):
	users = message.from_user.id
	await message.reply("Підписуйся на козаків, та будеш мати мощний член!\n\nInstagram:\n\nhttps://instagram.com/vova_chetvertinovski\nhttps://instagram.com/night.ddin\n\nТакож підписуйся на телеграм канал: https://t.me/Huge_piska_channel")

@dp.message_handler(commands=['help_ukraine'])
async def help_for_army(message: types.Message):
  users = message.from_user.id
  await message.reply("Якщо ти не підорас, допоможи нашій Армії!\n\nIBAN: UA473223130000026005010063051\n\nPrivat24: 5168757408828020, 5168755910144399 (30% на розвиток бота, 70% на ЗСУ!)\n\nЄДРПОУ: 14281072")

if __name__ == '__main__':
    executor.start_polling(dp)