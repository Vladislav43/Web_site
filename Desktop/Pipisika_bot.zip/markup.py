from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


mainMenu = ReplyKeyboardMarkup(resize_keyboard = True)
btnProffile = KeyboardButton("Реф-Профіль")
mainMenu.add(btnProffile)
